const degrees = [
  {
    school: 'Stanford University',
    degree: 'M.S. Computational and Mathematical Engineering',
    link: 'https://stanford.edu',
    year: 2016,
  },
  {
    school: 'University at Buffalo',
    degree: 'B.S. Electrical Engineering, Computer Engineering',
    link: 'https://buffalo.edu',
    year: 2012,
  },
];

export default degrees;
